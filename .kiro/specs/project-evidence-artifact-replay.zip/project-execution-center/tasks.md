# 任务清单：Project Execution Center

- [ ] 任务中心读取当前项目并默认按 `projectId` 过滤
- [ ] 增加项目选择或项目过滤入口
- [ ] 任务卡片显示所属项目、路线、spec 来源
- [ ] 支持未归档任务展示
- [ ] 支持将未归档任务关联到当前项目
- [ ] operator action 写入 `ProjectMessage` 和 `ProjectEvidence`
- [ ] 任务日志和 artifact 归档到项目
- [ ] 任务详情展示 route / role / runtime / evidence 关系
- [ ] 调整任务中心文案，弱化新建任务入口
- [ ] 补充 `/tasks` 测试，覆盖项目过滤、未归档任务、终止/重试回写

