# 任务清单：Project FSD Route Planner

- [ ] 定义项目级 route planner input / output 类型
- [ ] 读取 current project、current spec、recent messages 和 constraints
- [ ] 生成推荐、快速、深度、保守四类路线
- [ ] 在 Project Cockpit 展示路线卡片
- [ ] 支持用户选择路线并写入 `ProjectRoute`
- [ ] 将路线转换为 mission plan，带 `projectId`、`specId`、`routeId`
- [ ] 在任务详情展示路线来源和角色映射
- [ ] 将路线选择、调整和 replan 写入 `ProjectEvidence`
- [ ] 支持 spec 更新或失败任务触发 replan
- [ ] 补充测试，覆盖路线生成、选择、mission 关联和 replan

