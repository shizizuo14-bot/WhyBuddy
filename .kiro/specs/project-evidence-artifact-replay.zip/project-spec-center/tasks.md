# 任务清单：Project Spec Center

- [ ] 定义 `ProjectSpec` 和 spec completeness 类型
- [ ] 实现从项目目标和澄清生成初始 spec 草案的接口
- [ ] 支持 spec 版本创建、接受、替代
- [ ] 在 Project Cockpit 展示当前 spec 摘要和完整度
- [ ] 实现 Spec Center 页面或面板入口
- [ ] 记录 spec 来源 message / evidence / artifact
- [ ] 实现相邻版本 diff 摘要
- [ ] 支持用户确认或编辑 spec
- [ ] 执行结果和用户决策可生成 spec 更新建议
- [ ] 补充测试，覆盖 spec 版本、来源、完整度和 route 引用

