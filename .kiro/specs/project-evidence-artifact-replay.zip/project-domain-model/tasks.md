# 任务清单：Project Domain Model

- [ ] 新增 `Project`、`ProjectStatus`、`ProjectMessage`、`ProjectSpec`、`ProjectRoute`、`ProjectMission`、`ProjectArtifact`、`ProjectEvidence` 类型
- [ ] 新增 project store，支持 schema version 和 localStorage 持久化
- [ ] 实现创建项目、选择当前项目、更新项目、归档项目
- [ ] 实现当前项目选择状态，并在刷新页面后恢复
- [ ] 实现项目问答和澄清消息写入 `ProjectMessage`
- [ ] 实现 spec、route、mission、artifact、evidence 的项目关联写入接口
- [ ] 在任务创建成功后写入 `ProjectMission`
- [ ] 为历史未绑定任务提供 `unassigned` 展示或归档入口
- [ ] 为 store 添加单元测试，覆盖创建、选择、持久化、迁移和关联写入
- [ ] 为后续服务端迁移保留 schema version 和 migration 函数

