# 任务清单：Project Clarification & Conversation

- [ ] 定义项目澄清问题类型和 store 接口
- [ ] 将现有补问状态关联到 `projectId`
- [ ] 澄清问题生成时写入 `ProjectMessage`
- [ ] 用户回答后写入 `ProjectMessage` 和 `ProjectEvidence`
- [ ] 支持澄清问题的必答、可跳过和默认假设
- [ ] 在 Project Cockpit 展示当前缺失信息和澄清进度
- [ ] 将澄清回答作为 `ProjectSpec` 来源
- [ ] 在任务执行接管问题中复用项目澄清记录
- [ ] 补充测试，覆盖多轮澄清、跳过澄清、合并回答和 spec 来源关联

