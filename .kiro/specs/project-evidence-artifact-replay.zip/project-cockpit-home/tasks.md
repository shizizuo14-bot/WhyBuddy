# 任务清单：Project Cockpit Home

- [ ] 在 Home 中接入当前项目状态
- [ ] 实现无项目首页空状态：创建项目、模板、导入资料
- [ ] 实现当前项目 header：项目选择、状态、目标摘要
- [ ] 将首页主文案从“发起任务”调整为“推进当前项目”
- [ ] 将 `UnifiedLaunchComposer` 嵌入当前项目上下文
- [ ] 为项目阶段实现不同的主面板展示
- [ ] 将任务中心入口改为“查看执行明细 / 接管任务”
- [ ] 将 3D Office / HUD 文案和视觉权重调整为状态可视化
- [ ] 增加项目沉淀摘要：Spec、Route、Missions、Artifacts、Evidence
- [ ] 确保窄屏下当前项目、下一步建议和输入框优先展示
- [ ] 补充 Home / OfficeTaskCockpit 测试，覆盖无项目、有项目、执行中状态

