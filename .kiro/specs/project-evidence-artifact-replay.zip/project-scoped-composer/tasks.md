# 任务清单：Project-Scoped Composer

- [ ] 为 `UnifiedLaunchComposer` 增加当前项目上下文输入
- [ ] 无项目时将输入转为创建项目动作
- [ ] 有项目时更新 placeholder 和按钮语义
- [ ] 提交前写入 `ProjectMessage`
- [ ] 附件上传或选择时关联 `projectId`
- [ ] 路由判断时读取项目状态、当前 spec、当前 route、最近消息
- [ ] 任务创建成功后写入 `ProjectMission`
- [ ] 澄清问题和回答写回 `ProjectMessage`
- [ ] 路线判断结果写入 `ProjectRoute`
- [ ] 错误、运行时升级和用户取消动作写入项目 evidence
- [ ] 补充 `UnifiedLaunchComposer` 测试，覆盖无项目、有项目、澄清、任务创建路径

