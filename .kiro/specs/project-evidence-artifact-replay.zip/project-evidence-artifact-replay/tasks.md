# 任务清单：Project Evidence, Artifact & Replay

- [ ] 定义 `ProjectArtifact` 和 `ProjectEvidence` 类型
- [ ] 用户输入、澄清、路线选择、operator action 写入 evidence
- [ ] mission 创建、完成、失败、取消时写入 evidence
- [ ] runtime logs 和 artifacts 关联 `projectId`
- [ ] Project Cockpit 展示最近 evidence 和 artifact 摘要
- [ ] Project Execution Center 展示任务级证据和产物
- [ ] 实现项目 replay timeline 的最小版本
- [ ] SVG 架构图和进度图支持作为 project artifact 引用
- [ ] spec 版本引用 evidence / artifact 来源
- [ ] 补充测试，覆盖 evidence 写入、artifact 关联、replay timeline 排序

